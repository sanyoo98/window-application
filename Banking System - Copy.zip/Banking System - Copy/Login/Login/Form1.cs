﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class Form1 : Form
    {

        SqlConnection cnBank;
        SqlCommand cmdBank;
        SqlDataReader drBank;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cnBank = new SqlConnection("server=.;database=BankingSystem;Integrated Security=SSPI");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txtUserid.Text=="")
            {
                MessageBox.Show("Please Enter Userid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUserid.Focus();
                return;
            }
            if (txtPassword.Text == "")
            {
                MessageBox.Show("Please Enter Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Focus();
                return;
            }
            try
            {
                cmdBank = new SqlCommand("select userid,password from Login where userid=@userid AND password=@password",cnBank);

                SqlParameter uId = new SqlParameter("@userid", SqlDbType.VarChar);
                SqlParameter uPass = new SqlParameter("@password", SqlDbType.VarChar);

                uId.Value = txtUserid.Text;
                uPass.Value = txtPassword.Text;

                cmdBank.Parameters.Add(uId);
                cmdBank.Parameters.Add(uPass);

                cnBank.Open();

                drBank = cmdBank.ExecuteReader(CommandBehavior.CloseConnection);


                if(drBank.Read()==true)
                {
                    MessageBox.Show("You have logged in successfully" + " "+ txtUserid.Text);
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Login Failed......Try again!", "Login Denied", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtUserid.Clear();
                    txtPassword.Clear();
                    txtUserid.Focus();
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if(txtUserid.Text=="Admin123" || txtUserid.Text=="admin123")
            { 
            new Report().Show();
            this.Hide();
            }
            else
            {
                new Transaction().Show();
                this.Hide();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new RegisterUser().Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
