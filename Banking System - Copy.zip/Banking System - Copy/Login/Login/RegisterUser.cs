﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class RegisterUser : Form
    {
        SqlConnection cnBank;
        SqlCommand cmdBank;
        //SqlDataReader drBank;
        public RegisterUser()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if(txtuserid.Text=="")
            {
                MessageBox.Show("Please Enter UserId","error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtuserid.Focus();
                return;
            }
            if (txtpass.Text == "")
            {
                MessageBox.Show("Please Enter Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtpass.Focus();
                return;
            }
            if (txtcustname.Text == "")
            {
                MessageBox.Show("Please Enter UserId", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtcustname.Focus();
                return;
            }
            if (txtcontact.Text == "")
            {
                MessageBox.Show("Please Enter Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtcontact.Focus();
                return;
            }

            //object sel = ComboBox.SelectedValue;
            String s = "";
            if (ComboBox.SelectedIndex >= 0)
            {
                s = ComboBox.Items[ComboBox.SelectedIndex].ToString();
            }

             cnBank = new SqlConnection("server=.;database=BankingSystem;Integrated Security=SSPI");
            
             cmdBank = new SqlCommand("usp_insertCustomer1", cnBank);
             cmdBank.CommandType = CommandType.StoredProcedure;

             cmdBank.Parameters.AddWithValue("@custname", txtcustname.Text);
             cmdBank.Parameters.AddWithValue("@custAdd", txtaddress.Text);
             cmdBank.Parameters.AddWithValue("@contact_no", txtcontact.Text);
             cmdBank.Parameters.AddWithValue("@Acc_type", s);
             cmdBank.Parameters.AddWithValue("@userid", txtuserid.Text);
             cmdBank.Parameters.AddWithValue("@custPass", txtpass.Text);
            /*if(rdSaving.Checked)
            {
                cmdBank.Parameters.AddWithValue("Acc_type", "Savings");
                MessageBox.Show("value:" + rdSaving.);
            }
            else
            {
                cmdBank.Parameters.AddWithValue("Acc_type", "Current");
                MessageBox.Show("value:" + rdCurrent.Checked.ToString());
            }*/
   
            MessageBox.Show(cmdBank.Parameters.ToString());
            cnBank.Open();
            int i = cmdBank.ExecuteNonQuery();
            cnBank.Close();

           if(i!=0)
           { 
            MessageBox.Show("Customer Added into System with userid " + txtuserid.Text);
           }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        private void RegisterUser_Load(object sender, EventArgs e)
        {
            cnBank = new SqlConnection("server=.;database=BankingSystem;Integrated Security=SSPI");
        }

        private void ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            Regex re = new Regex("^9[0-9]{9}");

            if (re.IsMatch(txtcontact.Text.Trim()) == false || txtcontact.Text.Length > 10)
            {
                MessageBox.Show("Invalid Indian Mobile Number!!");
                txtcontact.Focus();
            }
            else
            {
                MessageBox.Show("Valid Indian Mobile Number!!");
                txtcontact.Focus();
            }
        }
    }
}
