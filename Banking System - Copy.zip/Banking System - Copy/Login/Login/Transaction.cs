﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class Transaction : Form
    {
        SqlConnection cnBank;
        SqlCommand cmdBank;
        SqlDataReader drBank;
        public Transaction()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Transaction_Load(object sender, EventArgs e)
        {
            cnBank = new SqlConnection("server=.;database=BankingSystem;Integrated Security=SSPI");
            cmdBank = new SqlCommand("Select custId Acc_no");
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
