﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class Report : Form
    {
        SqlConnection cnBank;
        SqlCommand cmdBank;
        SqlDataReader drBank;
        SqlDataAdapter daBank;
        DataSet dsBank = new DataSet();
        DataView dvBank;


        public Report()
        {
            InitializeComponent();
        }

        private void Report_Load(object sender, EventArgs e)
        {
            cnBank = new SqlConnection("server=.;database=BankingSystem;Integrated Security=SSPI");
            cmdBank = new SqlCommand("select CustId from Customer", cnBank);
            cnBank.Open();
            SqlDataReader drBank = cmdBank.ExecuteReader();
            while (drBank.Read())
            {
                cboCustid.Items.Add(drBank["CustId"].ToString());
            }
            cnBank.Close();

            daBank = new SqlDataAdapter("Select * from Account", cnBank);
            daBank.Fill(dsBank, "Account");
            dvBank = new DataView(dsBank.Tables["Account"]);
            dgBank.DataSource = dvBank;
            cboCustid.SelectedIndex = 0;
    }

        private void cboCustid_SelectedIndexChanged(object sender, EventArgs e)
        {
            dvBank.RowFilter = "CustId =  '" + cboCustid.SelectedItem.ToString() + "'";
        }
    }
}
