﻿namespace BankWindowsApplication
{
    partial class Withdraw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_AO = new System.Windows.Forms.Label();
            this.lbl_custid = new System.Windows.Forms.Label();
            this.lbl_accno = new System.Windows.Forms.Label();
            this.lbl_depo = new System.Windows.Forms.Label();
            this.txtcustid = new System.Windows.Forms.TextBox();
            this.txtAccno = new System.Windows.Forms.TextBox();
            this.txtdepo = new System.Windows.Forms.TextBox();
            this.btn_submit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_AO
            // 
            this.lbl_AO.AutoSize = true;
            this.lbl_AO.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AO.ForeColor = System.Drawing.Color.Blue;
            this.lbl_AO.Location = new System.Drawing.Point(52, 9);
            this.lbl_AO.Name = "lbl_AO";
            this.lbl_AO.Size = new System.Drawing.Size(177, 17);
            this.lbl_AO.TabIndex = 5;
            this.lbl_AO.Text = "User Operation: withdraw";
            // 
            // lbl_custid
            // 
            this.lbl_custid.AutoSize = true;
            this.lbl_custid.Location = new System.Drawing.Point(13, 47);
            this.lbl_custid.Name = "lbl_custid";
            this.lbl_custid.Size = new System.Drawing.Size(63, 13);
            this.lbl_custid.TabIndex = 6;
            this.lbl_custid.Text = "Customer Id";
            // 
            // lbl_accno
            // 
            this.lbl_accno.AutoSize = true;
            this.lbl_accno.Location = new System.Drawing.Point(13, 73);
            this.lbl_accno.Name = "lbl_accno";
            this.lbl_accno.Size = new System.Drawing.Size(62, 13);
            this.lbl_accno.TabIndex = 7;
            this.lbl_accno.Text = "Account no";
            // 
            // lbl_depo
            // 
            this.lbl_depo.AutoSize = true;
            this.lbl_depo.Location = new System.Drawing.Point(13, 99);
            this.lbl_depo.Name = "lbl_depo";
            this.lbl_depo.Size = new System.Drawing.Size(118, 13);
            this.lbl_depo.TabIndex = 8;
            this.lbl_depo.Text = "Amount to be Withdraw";
            // 
            // txtcustid
            // 
            this.txtcustid.Location = new System.Drawing.Point(151, 44);
            this.txtcustid.Name = "txtcustid";
            this.txtcustid.Size = new System.Drawing.Size(100, 20);
            this.txtcustid.TabIndex = 10;
            // 
            // txtAccno
            // 
            this.txtAccno.Location = new System.Drawing.Point(151, 70);
            this.txtAccno.Name = "txtAccno";
            this.txtAccno.Size = new System.Drawing.Size(100, 20);
            this.txtAccno.TabIndex = 11;
            // 
            // txtdepo
            // 
            this.txtdepo.Location = new System.Drawing.Point(151, 96);
            this.txtdepo.Name = "txtdepo";
            this.txtdepo.Size = new System.Drawing.Size(100, 20);
            this.txtdepo.TabIndex = 12;
            // 
            // btn_submit
            // 
            this.btn_submit.Location = new System.Drawing.Point(94, 142);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(75, 23);
            this.btn_submit.TabIndex = 14;
            this.btn_submit.Text = "Submit";
            this.btn_submit.UseVisualStyleBackColor = true;
            // 
            // Withdraw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 177);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.txtdepo);
            this.Controls.Add(this.txtAccno);
            this.Controls.Add(this.txtcustid);
            this.Controls.Add(this.lbl_depo);
            this.Controls.Add(this.lbl_accno);
            this.Controls.Add(this.lbl_custid);
            this.Controls.Add(this.lbl_AO);
            this.Name = "Withdraw";
            this.Text = "Withdraw";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_AO;
        private System.Windows.Forms.Label lbl_custid;
        private System.Windows.Forms.Label lbl_accno;
        private System.Windows.Forms.Label lbl_depo;
        private System.Windows.Forms.TextBox txtcustid;
        private System.Windows.Forms.TextBox txtAccno;
        private System.Windows.Forms.TextBox txtdepo;
        private System.Windows.Forms.Button btn_submit;
    }
}