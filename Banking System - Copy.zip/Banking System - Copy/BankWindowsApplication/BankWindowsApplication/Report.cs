﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectionConfiguration;

namespace BankWindowsApplication
{
    public partial class Report : Form
    {
        DAL dalObj = new DAL();
        public Report()
        {
            InitializeComponent();
        }

        public void com_cust_SelectedIndexChanged(object sender, EventArgs e)
        {
            dalObj.Report(com_cust, dgAccount);  
        }

        private void Report_Load(object sender, EventArgs e)
        {

        }
    }
}
