﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectionConfiguration;

namespace BankWindowsApplication
{
    public partial class RegisterUser : Form
    {
        public RegisterUser()
        {
            InitializeComponent();
        }

        DAL dalObj = new DAL();

        private void lbl_registraion_Click(object sender, EventArgs e)
        {

        }

        public void btn_submit_Click(object sender, EventArgs e)
        {
            if (txtusername.Text == "")
            {
                MessageBox.Show("Please Enter Username", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtusername.Focus();
                return;
            }
            if (txtpass.Text == "")
            {
                MessageBox.Show("Please Enter Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtpass.Focus();
                return;
            }
            if (txtcustname.Text == "")
            {
                MessageBox.Show("Please Enter UserId", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtcustname.Focus();
                return;
            }
            if (txtcontact.Text == "")
            {
                MessageBox.Show("Please Enter Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtcontact.Focus();
                return;
            }

          
        }

        private void RegisterUser_Load(object sender, EventArgs e)
        {

        }
    }
}
