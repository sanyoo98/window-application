﻿namespace BankWindowsApplication
{
    partial class UpdateCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_AO = new System.Windows.Forms.Label();
            this.lbl_updateEmp = new System.Windows.Forms.Label();
            this.lblcustid = new System.Windows.Forms.Label();
            this.btn_updCust = new System.Windows.Forms.Button();
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_contact = new System.Windows.Forms.Label();
            this.txtcustid = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_AO
            // 
            this.lbl_AO.AutoSize = true;
            this.lbl_AO.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AO.ForeColor = System.Drawing.Color.Blue;
            this.lbl_AO.Location = new System.Drawing.Point(55, 9);
            this.lbl_AO.Name = "lbl_AO";
            this.lbl_AO.Size = new System.Drawing.Size(128, 17);
            this.lbl_AO.TabIndex = 4;
            this.lbl_AO.Text = "Admin Operations";
            // 
            // lbl_updateEmp
            // 
            this.lbl_updateEmp.AutoSize = true;
            this.lbl_updateEmp.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_updateEmp.ForeColor = System.Drawing.Color.DimGray;
            this.lbl_updateEmp.Location = new System.Drawing.Point(12, 36);
            this.lbl_updateEmp.Name = "lbl_updateEmp";
            this.lbl_updateEmp.Size = new System.Drawing.Size(95, 15);
            this.lbl_updateEmp.TabIndex = 5;
            this.lbl_updateEmp.Text = "Update Employee";
            // 
            // lblcustid
            // 
            this.lblcustid.AutoSize = true;
            this.lblcustid.Location = new System.Drawing.Point(12, 71);
            this.lblcustid.Name = "lblcustid";
            this.lblcustid.Size = new System.Drawing.Size(65, 13);
            this.lblcustid.TabIndex = 6;
            this.lblcustid.Text = "Customer ID";
            // 
            // btn_updCust
            // 
            this.btn_updCust.Location = new System.Drawing.Point(58, 162);
            this.btn_updCust.Name = "btn_updCust";
            this.btn_updCust.Size = new System.Drawing.Size(75, 23);
            this.btn_updCust.TabIndex = 14;
            this.btn_updCust.Text = "Update";
            this.btn_updCust.UseVisualStyleBackColor = true;
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Location = new System.Drawing.Point(12, 95);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(35, 13);
            this.lbl_name.TabIndex = 15;
            this.lbl_name.Text = "Name";
            // 
            // lbl_contact
            // 
            this.lbl_contact.AutoSize = true;
            this.lbl_contact.Location = new System.Drawing.Point(12, 119);
            this.lbl_contact.Name = "lbl_contact";
            this.lbl_contact.Size = new System.Drawing.Size(62, 13);
            this.lbl_contact.TabIndex = 16;
            this.lbl_contact.Text = "Contact no.";
            // 
            // txtcustid
            // 
            this.txtcustid.Location = new System.Drawing.Point(91, 71);
            this.txtcustid.Name = "txtcustid";
            this.txtcustid.Size = new System.Drawing.Size(100, 20);
            this.txtcustid.TabIndex = 17;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(91, 97);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(100, 20);
            this.txtname.TabIndex = 18;
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(91, 123);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(100, 20);
            this.txtContact.TabIndex = 19;
            // 
            // UpdateCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(224, 197);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtcustid);
            this.Controls.Add(this.lbl_contact);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.btn_updCust);
            this.Controls.Add(this.lblcustid);
            this.Controls.Add(this.lbl_updateEmp);
            this.Controls.Add(this.lbl_AO);
            this.Name = "UpdateCustomer";
            this.Text = "UpdateCustomer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_AO;
        private System.Windows.Forms.Label lbl_updateEmp;
        private System.Windows.Forms.Label lblcustid;
        private System.Windows.Forms.Button btn_updCust;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_contact;
        private System.Windows.Forms.TextBox txtcustid;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtContact;
    }
}