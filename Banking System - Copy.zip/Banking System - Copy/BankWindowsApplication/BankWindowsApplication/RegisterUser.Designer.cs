﻿namespace BankWindowsApplication
{
    partial class RegisterUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_registraion = new System.Windows.Forms.Label();
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_add = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_uname = new System.Windows.Forms.Label();
            this.lbl_uPass = new System.Windows.Forms.Label();
            this.lbl_type = new System.Windows.Forms.Label();
            this.txtcustname = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtcontact = new System.Windows.Forms.TextBox();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.comb_type = new System.Windows.Forms.ComboBox();
            this.btn_submit = new System.Windows.Forms.Button();
            this.btn_signup = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_registraion
            // 
            this.lbl_registraion.AutoSize = true;
            this.lbl_registraion.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_registraion.Location = new System.Drawing.Point(66, 20);
            this.lbl_registraion.Name = "lbl_registraion";
            this.lbl_registraion.Size = new System.Drawing.Size(146, 17);
            this.lbl_registraion.TabIndex = 0;
            this.lbl_registraion.Text = "User Registration Form";
            this.lbl_registraion.Click += new System.EventHandler(this.lbl_registraion_Click);
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(25, 51);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(35, 15);
            this.lbl_name.TabIndex = 1;
            this.lbl_name.Text = "Name";
            // 
            // lbl_add
            // 
            this.lbl_add.AutoSize = true;
            this.lbl_add.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_add.Location = new System.Drawing.Point(25, 77);
            this.lbl_add.Name = "lbl_add";
            this.lbl_add.Size = new System.Drawing.Size(47, 15);
            this.lbl_add.TabIndex = 2;
            this.lbl_add.Text = "Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Contact No.";
            // 
            // lbl_uname
            // 
            this.lbl_uname.AutoSize = true;
            this.lbl_uname.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_uname.Location = new System.Drawing.Point(25, 161);
            this.lbl_uname.Name = "lbl_uname";
            this.lbl_uname.Size = new System.Drawing.Size(55, 15);
            this.lbl_uname.TabIndex = 4;
            this.lbl_uname.Text = "Username";
            // 
            // lbl_uPass
            // 
            this.lbl_uPass.AutoSize = true;
            this.lbl_uPass.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_uPass.Location = new System.Drawing.Point(25, 191);
            this.lbl_uPass.Name = "lbl_uPass";
            this.lbl_uPass.Size = new System.Drawing.Size(54, 15);
            this.lbl_uPass.TabIndex = 5;
            this.lbl_uPass.Text = "Password";
            // 
            // lbl_type
            // 
            this.lbl_type.AutoSize = true;
            this.lbl_type.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_type.Location = new System.Drawing.Point(25, 219);
            this.lbl_type.Name = "lbl_type";
            this.lbl_type.Size = new System.Drawing.Size(77, 15);
            this.lbl_type.TabIndex = 6;
            this.lbl_type.Text = "Account Type";
            // 
            // txtcustname
            // 
            this.txtcustname.Location = new System.Drawing.Point(123, 51);
            this.txtcustname.Name = "txtcustname";
            this.txtcustname.Size = new System.Drawing.Size(130, 20);
            this.txtcustname.TabIndex = 7;
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(123, 77);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(130, 47);
            this.txtaddress.TabIndex = 8;
            // 
            // txtcontact
            // 
            this.txtcontact.Location = new System.Drawing.Point(123, 130);
            this.txtcontact.Name = "txtcontact";
            this.txtcontact.Size = new System.Drawing.Size(130, 20);
            this.txtcontact.TabIndex = 9;
            // 
            // txtusername
            // 
            this.txtusername.Location = new System.Drawing.Point(123, 159);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(130, 20);
            this.txtusername.TabIndex = 10;
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(123, 189);
            this.txtpass.Name = "txtpass";
            this.txtpass.Size = new System.Drawing.Size(130, 20);
            this.txtpass.TabIndex = 11;
            // 
            // comb_type
            // 
            this.comb_type.FormattingEnabled = true;
            this.comb_type.Items.AddRange(new object[] {
            "Savings",
            "Current"});
            this.comb_type.Location = new System.Drawing.Point(123, 219);
            this.comb_type.Name = "comb_type";
            this.comb_type.Size = new System.Drawing.Size(130, 21);
            this.comb_type.TabIndex = 13;
            // 
            // btn_submit
            // 
            this.btn_submit.Location = new System.Drawing.Point(56, 263);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(75, 23);
            this.btn_submit.TabIndex = 14;
            this.btn_submit.Text = "Submit";
            this.btn_submit.UseVisualStyleBackColor = true;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // btn_signup
            // 
            this.btn_signup.Location = new System.Drawing.Point(148, 263);
            this.btn_signup.Name = "btn_signup";
            this.btn_signup.Size = new System.Drawing.Size(75, 23);
            this.btn_signup.TabIndex = 15;
            this.btn_signup.Text = "Sign Up";
            this.btn_signup.UseVisualStyleBackColor = true;
            // 
            // RegisterUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(318, 296);
            this.Controls.Add(this.btn_signup);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.comb_type);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.txtusername);
            this.Controls.Add(this.txtcontact);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.txtcustname);
            this.Controls.Add(this.lbl_type);
            this.Controls.Add(this.lbl_uPass);
            this.Controls.Add(this.lbl_uname);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbl_add);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.lbl_registraion);
            this.Name = "RegisterUser";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.RegisterUser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_registraion;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_add;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_uname;
        private System.Windows.Forms.Label lbl_uPass;
        private System.Windows.Forms.Label lbl_type;
        private System.Windows.Forms.TextBox txtcustname;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtcontact;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.ComboBox comb_type;
        private System.Windows.Forms.Button btn_submit;
        private System.Windows.Forms.Button btn_signup;
    }
}