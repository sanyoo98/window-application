﻿namespace BankWindowsApplication
{
    partial class UpdateEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_AO = new System.Windows.Forms.Label();
            this.lbl_updateEmp = new System.Windows.Forms.Label();
            this.lblEmpid = new System.Windows.Forms.Label();
            this.lbl_loc = new System.Windows.Forms.Label();
            this.lbl_phone = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lbl_branch = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.btn_updEmp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_AO
            // 
            this.lbl_AO.AutoSize = true;
            this.lbl_AO.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AO.ForeColor = System.Drawing.Color.Blue;
            this.lbl_AO.Location = new System.Drawing.Point(63, 9);
            this.lbl_AO.Name = "lbl_AO";
            this.lbl_AO.Size = new System.Drawing.Size(128, 17);
            this.lbl_AO.TabIndex = 3;
            this.lbl_AO.Text = "Admin Operations";
            // 
            // lbl_updateEmp
            // 
            this.lbl_updateEmp.AutoSize = true;
            this.lbl_updateEmp.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_updateEmp.ForeColor = System.Drawing.Color.DimGray;
            this.lbl_updateEmp.Location = new System.Drawing.Point(12, 36);
            this.lbl_updateEmp.Name = "lbl_updateEmp";
            this.lbl_updateEmp.Size = new System.Drawing.Size(95, 15);
            this.lbl_updateEmp.TabIndex = 4;
            this.lbl_updateEmp.Text = "Update Employee";
            // 
            // lblEmpid
            // 
            this.lblEmpid.AutoSize = true;
            this.lblEmpid.Location = new System.Drawing.Point(12, 68);
            this.lblEmpid.Name = "lblEmpid";
            this.lblEmpid.Size = new System.Drawing.Size(67, 13);
            this.lblEmpid.TabIndex = 5;
            this.lblEmpid.Text = "Employee ID";
            // 
            // lbl_loc
            // 
            this.lbl_loc.AutoSize = true;
            this.lbl_loc.Location = new System.Drawing.Point(12, 94);
            this.lbl_loc.Name = "lbl_loc";
            this.lbl_loc.Size = new System.Drawing.Size(48, 13);
            this.lbl_loc.TabIndex = 6;
            this.lbl_loc.Text = "Location";
            // 
            // lbl_phone
            // 
            this.lbl_phone.AutoSize = true;
            this.lbl_phone.Location = new System.Drawing.Point(12, 120);
            this.lbl_phone.Name = "lbl_phone";
            this.lbl_phone.Size = new System.Drawing.Size(62, 13);
            this.lbl_phone.TabIndex = 7;
            this.lbl_phone.Text = "Contact no.";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(120, 65);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 8;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(120, 91);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 9;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(120, 117);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 10;
            // 
            // lbl_branch
            // 
            this.lbl_branch.AutoSize = true;
            this.lbl_branch.Location = new System.Drawing.Point(12, 146);
            this.lbl_branch.Name = "lbl_branch";
            this.lbl_branch.Size = new System.Drawing.Size(41, 13);
            this.lbl_branch.TabIndex = 11;
            this.lbl_branch.Text = "Branch";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(120, 143);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 12;
            // 
            // btn_updEmp
            // 
            this.btn_updEmp.Location = new System.Drawing.Point(55, 169);
            this.btn_updEmp.Name = "btn_updEmp";
            this.btn_updEmp.Size = new System.Drawing.Size(75, 23);
            this.btn_updEmp.TabIndex = 13;
            this.btn_updEmp.Text = "Update";
            this.btn_updEmp.UseVisualStyleBackColor = true;
            // 
            // UpdateEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(251, 196);
            this.Controls.Add(this.btn_updEmp);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.lbl_branch);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbl_phone);
            this.Controls.Add(this.lbl_loc);
            this.Controls.Add(this.lblEmpid);
            this.Controls.Add(this.lbl_updateEmp);
            this.Controls.Add(this.lbl_AO);
            this.Name = "UpdateEmployee";
            this.Text = "UpdateEmployee";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_AO;
        private System.Windows.Forms.Label lbl_updateEmp;
        private System.Windows.Forms.Label lblEmpid;
        private System.Windows.Forms.Label lbl_loc;
        private System.Windows.Forms.Label lbl_phone;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lbl_branch;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button btn_updEmp;
    }
}