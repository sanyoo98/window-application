﻿namespace BankWindowsApplication
{
    partial class AddCust
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_custid = new System.Windows.Forms.Label();
            this.lbl_addemp = new System.Windows.Forms.Label();
            this.lbl_accno = new System.Windows.Forms.Label();
            this.lbl_type = new System.Windows.Forms.Label();
            this.lbl_bal = new System.Windows.Forms.Label();
            this.txtcustid = new System.Windows.Forms.TextBox();
            this.txtAccno = new System.Windows.Forms.TextBox();
            this.txt_type = new System.Windows.Forms.TextBox();
            this.txtAmt = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_custid
            // 
            this.lbl_custid.AutoSize = true;
            this.lbl_custid.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custid.Location = new System.Drawing.Point(12, 55);
            this.lbl_custid.Name = "lbl_custid";
            this.lbl_custid.Size = new System.Drawing.Size(82, 16);
            this.lbl_custid.TabIndex = 6;
            this.lbl_custid.Text = "Customer ID";
            // 
            // lbl_addemp
            // 
            this.lbl_addemp.AutoSize = true;
            this.lbl_addemp.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_addemp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_addemp.Location = new System.Drawing.Point(76, 18);
            this.lbl_addemp.Name = "lbl_addemp";
            this.lbl_addemp.Size = new System.Drawing.Size(128, 17);
            this.lbl_addemp.TabIndex = 7;
            this.lbl_addemp.Text = "Add New Employee";
            // 
            // lbl_accno
            // 
            this.lbl_accno.AutoSize = true;
            this.lbl_accno.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accno.Location = new System.Drawing.Point(12, 87);
            this.lbl_accno.Name = "lbl_accno";
            this.lbl_accno.Size = new System.Drawing.Size(81, 16);
            this.lbl_accno.TabIndex = 8;
            this.lbl_accno.Text = "Account No.";
            // 
            // lbl_type
            // 
            this.lbl_type.AutoSize = true;
            this.lbl_type.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_type.Location = new System.Drawing.Point(12, 122);
            this.lbl_type.Name = "lbl_type";
            this.lbl_type.Size = new System.Drawing.Size(88, 16);
            this.lbl_type.TabIndex = 9;
            this.lbl_type.Text = "Account Type";
            // 
            // lbl_bal
            // 
            this.lbl_bal.AutoSize = true;
            this.lbl_bal.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bal.Location = new System.Drawing.Point(12, 156);
            this.lbl_bal.Name = "lbl_bal";
            this.lbl_bal.Size = new System.Drawing.Size(53, 16);
            this.lbl_bal.TabIndex = 10;
            this.lbl_bal.Text = "Amount";
            // 
            // txtcustid
            // 
            this.txtcustid.Location = new System.Drawing.Point(136, 55);
            this.txtcustid.Name = "txtcustid";
            this.txtcustid.Size = new System.Drawing.Size(113, 20);
            this.txtcustid.TabIndex = 11;
            // 
            // txtAccno
            // 
            this.txtAccno.Location = new System.Drawing.Point(136, 87);
            this.txtAccno.Name = "txtAccno";
            this.txtAccno.Size = new System.Drawing.Size(113, 20);
            this.txtAccno.TabIndex = 12;
            // 
            // txt_type
            // 
            this.txt_type.Location = new System.Drawing.Point(136, 120);
            this.txt_type.Name = "txt_type";
            this.txt_type.Size = new System.Drawing.Size(113, 20);
            this.txt_type.TabIndex = 13;
            // 
            // txtAmt
            // 
            this.txtAmt.Location = new System.Drawing.Point(136, 154);
            this.txtAmt.Name = "txtAmt";
            this.txtAmt.Size = new System.Drawing.Size(113, 20);
            this.txtAmt.TabIndex = 14;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(92, 190);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 15;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            // 
            // AddCust
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 225);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.txtAmt);
            this.Controls.Add(this.txt_type);
            this.Controls.Add(this.txtAccno);
            this.Controls.Add(this.txtcustid);
            this.Controls.Add(this.lbl_bal);
            this.Controls.Add(this.lbl_type);
            this.Controls.Add(this.lbl_accno);
            this.Controls.Add(this.lbl_addemp);
            this.Controls.Add(this.lbl_custid);
            this.Name = "AddCust";
            this.Text = "AddCust";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl_custid;
        private System.Windows.Forms.Label lbl_addemp;
        private System.Windows.Forms.Label lbl_accno;
        private System.Windows.Forms.Label lbl_type;
        private System.Windows.Forms.Label lbl_bal;
        private System.Windows.Forms.TextBox txtcustid;
        private System.Windows.Forms.TextBox txtAccno;
        private System.Windows.Forms.TextBox txt_type;
        private System.Windows.Forms.TextBox txtAmt;
        private System.Windows.Forms.Button btn_add;
    }
}