﻿namespace BankWindowsApplication
{
    partial class AdminOperations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_newEmp = new System.Windows.Forms.Button();
            this.btn_report = new System.Windows.Forms.Button();
            this.lbl_AO = new System.Windows.Forms.Label();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_updCust = new System.Windows.Forms.Button();
            this.btn_updEmp = new System.Windows.Forms.Button();
            this.btn_addcust = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_newEmp
            // 
            this.btn_newEmp.Location = new System.Drawing.Point(71, 58);
            this.btn_newEmp.Name = "btn_newEmp";
            this.btn_newEmp.Size = new System.Drawing.Size(117, 23);
            this.btn_newEmp.TabIndex = 0;
            this.btn_newEmp.Text = "Add new Employee";
            this.btn_newEmp.UseVisualStyleBackColor = true;
            this.btn_newEmp.Click += new System.EventHandler(this.btn_newEmp_Click);
            // 
            // btn_report
            // 
            this.btn_report.Location = new System.Drawing.Point(71, 174);
            this.btn_report.Name = "btn_report";
            this.btn_report.Size = new System.Drawing.Size(117, 23);
            this.btn_report.TabIndex = 1;
            this.btn_report.Text = "Report ";
            this.btn_report.UseVisualStyleBackColor = true;
            this.btn_report.Click += new System.EventHandler(this.btn_report_Click);
            // 
            // lbl_AO
            // 
            this.lbl_AO.AutoSize = true;
            this.lbl_AO.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AO.Location = new System.Drawing.Point(68, 19);
            this.lbl_AO.Name = "lbl_AO";
            this.lbl_AO.Size = new System.Drawing.Size(128, 17);
            this.lbl_AO.TabIndex = 2;
            this.lbl_AO.Text = "Admin Operations";
            // 
            // btn_exit
            // 
            this.btn_exit.Location = new System.Drawing.Point(71, 203);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(117, 23);
            this.btn_exit.TabIndex = 3;
            this.btn_exit.Text = "Exit";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // btn_updCust
            // 
            this.btn_updCust.Location = new System.Drawing.Point(71, 145);
            this.btn_updCust.Name = "btn_updCust";
            this.btn_updCust.Size = new System.Drawing.Size(117, 23);
            this.btn_updCust.TabIndex = 4;
            this.btn_updCust.Text = "Update Customer";
            this.btn_updCust.UseVisualStyleBackColor = true;
            // 
            // btn_updEmp
            // 
            this.btn_updEmp.Location = new System.Drawing.Point(71, 116);
            this.btn_updEmp.Name = "btn_updEmp";
            this.btn_updEmp.Size = new System.Drawing.Size(117, 23);
            this.btn_updEmp.TabIndex = 5;
            this.btn_updEmp.Text = "Update Employee";
            this.btn_updEmp.UseVisualStyleBackColor = true;
            // 
            // btn_addcust
            // 
            this.btn_addcust.Location = new System.Drawing.Point(71, 87);
            this.btn_addcust.Name = "btn_addcust";
            this.btn_addcust.Size = new System.Drawing.Size(117, 23);
            this.btn_addcust.TabIndex = 6;
            this.btn_addcust.Text = "Add new Customer";
            this.btn_addcust.UseVisualStyleBackColor = true;
            // 
            // AdminOperations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(279, 238);
            this.Controls.Add(this.btn_addcust);
            this.Controls.Add(this.btn_updEmp);
            this.Controls.Add(this.btn_updCust);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.lbl_AO);
            this.Controls.Add(this.btn_report);
            this.Controls.Add(this.btn_newEmp);
            this.Name = "AdminOperations";
            this.Text = "AdminOperations";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_newEmp;
        private System.Windows.Forms.Button btn_report;
        private System.Windows.Forms.Label lbl_AO;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Button btn_updCust;
        private System.Windows.Forms.Button btn_updEmp;
        private System.Windows.Forms.Button btn_addcust;
    }
}