﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectionConfiguration;

namespace BankWindowsApplication
{
    public partial class Login : Form
    {
        static int attempt = 3;
        DAL dalObj = new DAL();
        public Login()
        {
            InitializeComponent();
            pictureBox1.Image = new Bitmap(@"D:\winApp\Banking System\BankWindowsApplication\BankWindowsApplication\Images\3.jpg");
        }

        private void Login_Load(object sender, EventArgs e)
        {
            dalObj.Connect();
        }

        public void btn_Login_Click(object sender, EventArgs e)
        {
            if (txtusername.Text == "")
            {
                MessageBox.Show("Please Enter Userid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtusername.Focus();
                return;
            }
            if (txtPassword.Text == "")
            {
                MessageBox.Show("Please Enter Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Focus();
                return;
            }
            try
            {
                dalObj.uName = txtusername.Text;
                dalObj.uPass = txtPassword.Text;

                if (attempt == 0)
                {
                    lbl.Text = ("ALL 3 ATTEMPTS HAVE FAILED - CONTACT ADMIN");
                    return;
                }

                if (dalObj.ValidateUser(txtusername.Text, txtPassword.Text) == 1)
                {
                    if (txtusername.Text == "Admin123" || txtusername.Text == "admin123")
                    {
                        pictureBox1.Image = new Bitmap(@"D:\winApp\Banking System\BankWindowsApplication\BankWindowsApplication\Images\4.jpg");
                        MessageBox.Show("YOU ARE GRANTED WITH ACCESS","you are logged in "+txtusername.Text);
                        new AdminOperations().Show();
                        this.Hide();
                    }
                    else if (txtusername.Text == "sanyoo" || txtusername.Text == "Sanyoo")
                        {
                            pictureBox1.Image = new Bitmap(@"D:\winApp\Banking System\BankWindowsApplication\BankWindowsApplication\Images\4.jpg");
                            MessageBox.Show("YOU ARE GRANTED WITH ACCESS", "you are logged in " + txtusername.Text);
                            new UserOperations().Show();
                            this.Hide();
                        }
                    else
                    { 
                        pictureBox1.Image = new Bitmap(@"D:\winApp\Banking System\BankWindowsApplication\BankWindowsApplication\Images\5.jpg");
                        MessageBox.Show("YOU ARE NOT GRANTED WITH ACCESS");
                        lbl.Text = ("You Have Only " + Convert.ToString(attempt) + " Attempt Left To Try");
                        --attempt;
                        txtusername.Clear();
                        txtPassword.Clear();
                    }
                }


                /*if (dalObj.ValidateUser(txtusername.Text, txtPassword.Text) == 1)
                {
                    MessageBox.Show("You have logged in successfully" + " " + txtusername.Text);
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Login Failed......Try again!", "Login Denied", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtusername.Clear();
                    txtPassword.Clear();
                    txtusername.Focus();
                }*/

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


                  /* lbl.Text = ("You Have Only " + Convert.ToString(attempt) + " Attempt Left To Try");
                    --attempt;
                    txtusername.Clear();
                    txtPassword.Clear();
                }


                if (drBank.Read() == true)
                {
                    MessageBox.Show("You have logged in successfully" + " " + txtusername.Text);
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Login Failed......Try again!", "Login Denied", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtusername.Clear();
                    txtPassword.Clear();
                    txtusername.Focus();
                }

            }*/


            if (txtusername.Text == "Admin123" || txtusername.Text == "admin123")
            {
                //new Report().Show();
                this.Hide();
            }
            else
            {
                //new Transaction().Show();
                this.Hide();
            }
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            new RegisterUser().Show();
            this.Hide();
        }
    }
}
