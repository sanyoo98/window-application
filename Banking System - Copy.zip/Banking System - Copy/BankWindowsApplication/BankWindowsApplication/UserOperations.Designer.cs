﻿namespace BankWindowsApplication
{
    partial class UserOperations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_AO = new System.Windows.Forms.Label();
            this.lbl_custid = new System.Windows.Forms.Label();
            this.lbl_accno = new System.Windows.Forms.Label();
            this.txtcustid = new System.Windows.Forms.TextBox();
            this.txtAccno = new System.Windows.Forms.TextBox();
            this.btn_depo = new System.Windows.Forms.Button();
            this.btn_with = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_AO
            // 
            this.lbl_AO.AutoSize = true;
            this.lbl_AO.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AO.ForeColor = System.Drawing.Color.Blue;
            this.lbl_AO.Location = new System.Drawing.Point(73, 23);
            this.lbl_AO.Name = "lbl_AO";
            this.lbl_AO.Size = new System.Drawing.Size(117, 17);
            this.lbl_AO.TabIndex = 3;
            this.lbl_AO.Text = "User Operations";
            // 
            // lbl_custid
            // 
            this.lbl_custid.AutoSize = true;
            this.lbl_custid.Location = new System.Drawing.Point(25, 66);
            this.lbl_custid.Name = "lbl_custid";
            this.lbl_custid.Size = new System.Drawing.Size(63, 13);
            this.lbl_custid.TabIndex = 4;
            this.lbl_custid.Text = "Customer Id";
            // 
            // lbl_accno
            // 
            this.lbl_accno.AutoSize = true;
            this.lbl_accno.Location = new System.Drawing.Point(25, 97);
            this.lbl_accno.Name = "lbl_accno";
            this.lbl_accno.Size = new System.Drawing.Size(65, 13);
            this.lbl_accno.TabIndex = 5;
            this.lbl_accno.Text = "Account no.";
            // 
            // txtcustid
            // 
            this.txtcustid.Location = new System.Drawing.Point(111, 63);
            this.txtcustid.Name = "txtcustid";
            this.txtcustid.Size = new System.Drawing.Size(100, 20);
            this.txtcustid.TabIndex = 6;
            // 
            // txtAccno
            // 
            this.txtAccno.Location = new System.Drawing.Point(111, 94);
            this.txtAccno.Name = "txtAccno";
            this.txtAccno.Size = new System.Drawing.Size(100, 20);
            this.txtAccno.TabIndex = 7;
            this.txtAccno.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btn_depo
            // 
            this.btn_depo.Location = new System.Drawing.Point(28, 135);
            this.btn_depo.Name = "btn_depo";
            this.btn_depo.Size = new System.Drawing.Size(75, 23);
            this.btn_depo.TabIndex = 8;
            this.btn_depo.Text = "Deposite";
            this.btn_depo.UseVisualStyleBackColor = true;
            // 
            // btn_with
            // 
            this.btn_with.Location = new System.Drawing.Point(136, 135);
            this.btn_with.Name = "btn_with";
            this.btn_with.Size = new System.Drawing.Size(75, 23);
            this.btn_with.TabIndex = 9;
            this.btn_with.Text = "Withdraw";
            this.btn_with.UseVisualStyleBackColor = true;
            // 
            // UserOperations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(245, 170);
            this.Controls.Add(this.btn_with);
            this.Controls.Add(this.btn_depo);
            this.Controls.Add(this.txtAccno);
            this.Controls.Add(this.txtcustid);
            this.Controls.Add(this.lbl_accno);
            this.Controls.Add(this.lbl_custid);
            this.Controls.Add(this.lbl_AO);
            this.Name = "UserOperations";
            this.Text = "cv";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_AO;
        private System.Windows.Forms.Label lbl_custid;
        private System.Windows.Forms.Label lbl_accno;
        private System.Windows.Forms.TextBox txtcustid;
        private System.Windows.Forms.TextBox txtAccno;
        private System.Windows.Forms.Button btn_depo;
        private System.Windows.Forms.Button btn_with;
    }
}