﻿namespace BankWindowsApplication
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_custid = new System.Windows.Forms.Label();
            this.com_cust = new System.Windows.Forms.ComboBox();
            this.dgAccount = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgAccount)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(100, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Report";
            // 
            // lbl_custid
            // 
            this.lbl_custid.AutoSize = true;
            this.lbl_custid.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custid.ForeColor = System.Drawing.Color.DimGray;
            this.lbl_custid.Location = new System.Drawing.Point(38, 70);
            this.lbl_custid.Name = "lbl_custid";
            this.lbl_custid.Size = new System.Drawing.Size(70, 15);
            this.lbl_custid.TabIndex = 1;
            this.lbl_custid.Text = "Custmoer ID";
            // 
            // com_cust
            // 
            this.com_cust.FormattingEnabled = true;
            this.com_cust.Location = new System.Drawing.Point(125, 68);
            this.com_cust.Name = "com_cust";
            this.com_cust.Size = new System.Drawing.Size(121, 21);
            this.com_cust.TabIndex = 2;
            this.com_cust.SelectedIndexChanged += new System.EventHandler(this.com_cust_SelectedIndexChanged);
            // 
            // dgAccount
            // 
            this.dgAccount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAccount.Location = new System.Drawing.Point(41, 117);
            this.dgAccount.Name = "dgAccount";
            this.dgAccount.Size = new System.Drawing.Size(205, 95);
            this.dgAccount.TabIndex = 3;
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.dgAccount);
            this.Controls.Add(this.com_cust);
            this.Controls.Add(this.lbl_custid);
            this.Controls.Add(this.label1);
            this.Name = "Report";
            this.Text = "Report";
            this.Load += new System.EventHandler(this.Report_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgAccount)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_custid;
        private System.Windows.Forms.ComboBox com_cust;
        private System.Windows.Forms.DataGridView dgAccount;
    }
}