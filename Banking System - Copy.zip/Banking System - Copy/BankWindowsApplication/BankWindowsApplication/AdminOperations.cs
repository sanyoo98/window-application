﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankWindowsApplication
{
    public partial class AdminOperations : Form
    {
        public AdminOperations()
        {
            InitializeComponent();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_report_Click(object sender, EventArgs e)
        {
            new Report().Show();
            this.Hide();
        }

        private void btn_newEmp_Click(object sender, EventArgs e)
        {
            new AddEmp().Show();
            this.Hide();
           
        }
    }
}
