﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConnectionConfiguration
{
    public class DAL
    {
        SqlConnection cnBank;
        SqlCommand cmdBank;
        SqlDataAdapter daBank;
        SqlDataReader drBank;
        DataSet dsBank;
        DataView dvBank;

        public string uName { get; set; }
        public string uPass { get; set; }
        string txtusername, txtPassword;
        string comb_type;
        

        public SqlConnection Connect()
        {
            cnBank = new SqlConnection("server=.;databasse=BankingSystem;Integreted security=SSPI");
            cnBank.Open();
            return cnBank;
        }

        public string ValidateUser(string username, string password)
        {
            cmdBank = new SqlCommand("select username,pass from Login where username=@username AND pass=@password", cnBank);
        }

        public int Insert(string txtcustname, string txtaddress,string txtcontact,string comb_type, string txtusername,string txtpass,int i)
        {
           /* if (comb_type.SelectedIndex >= 0)
            {
                s = comb_type.Items[comb_type.SelectedIndex].ToString();
            }*/
            cmdBank = new SqlCommand("usp_insertCustomer1", cnBank);
            cmdBank.CommandType = CommandType.StoredProcedure;
            cmdBank.Parameters.AddWithValue("@custname", txtcustname);
            cmdBank.Parameters.AddWithValue("@custAdd", txtaddress);
            cmdBank.Parameters.AddWithValue("@contact_no", txtcontact);
            cmdBank.Parameters.AddWithValue("@Acc_type",comb_type);
            cmdBank.Parameters.AddWithValue("@userid", txtusername);
            cmdBank.Parameters.AddWithValue("@custPass", txtpass);
            cnBank.Open();
            i = cmdBank.ExecuteNonQuery();
            cnBank.Close();
            if (i != 0)
            {
                return 0;
            }


            return 0;
        }

        public int InsertEmp(int i,string txtEmpname, string txtLoc, string txtContact, string txtDept,string txtbranch)
        {
            cmdBank = new SqlCommand("usp_insertEmployee", cnBank);
            cmdBank.CommandType = CommandType.StoredProcedure;
            cmdBank.Parameters.AddWithValue("@empname", txtEmpname);
            cmdBank.Parameters.AddWithValue("@loc", txtLoc);
            cmdBank.Parameters.AddWithValue("@contact_no", txtContact);
            cmdBank.Parameters.AddWithValue("@dept", txtDept);
            cmdBank.Parameters.AddWithValue("@branch", txtbranch);
            cnBank.Open();
            i = cmdBank.ExecuteNonQuery();
            cnBank.Close();
            if (i != 0)
            {
                return 0;
            }


            return 0;
        }
        public int AddCustomer(string txtcustid,string txtAccno,string txt_type, string txt_amt)
        {
            cmdBank = new SqlCommand("usp_insertAccount", cnBank);
            cmdBank.CommandType = CommandType.StoredProcedure;
            cmdBank.Parameters.AddWithValue("@empname", txtcustid);
            cmdBank.Parameters.AddWithValue("@loc", txtAccno);
            cmdBank.Parameters.AddWithValue("@contact_no", txt_type);
            cmdBank.Parameters.AddWithValue("@dept", txt_amt);
            cnBank.Open();
           int  i = cmdBank.ExecuteNonQuery();
            cnBank.Close();
        }
        public string Report( )
        {
            cmdBank = new SqlCommand("select CustId from Customer", cnBank);
            SqlDataReader drBank = cmdBank.ExecuteReader();
            drBank = cmdBank.ExecuteReader();
            if (drBank != null)
            {
                while (drBank.Read())
                {

                    //cboCustid.Items.Add(drBank["custId"]);

                }
            }

            daBank = new SqlDataAdapter("Select * from Account", cnBank);
            daBank.Fill(dsBank, "Account");
            dvBank = new DataView(dsBank.Tables["Account"]);
            //dgBank.DataSource= dvBank;
           // cboCustid.Select = drBank[CustId];
                //.SelectedIndex = 0;
        }
        public string Deposite()
        {
            return null;
        }
        public string Withdraw()
        {
            return null;
        }

        public string Disconnect()
        {
            int i = cmdBank.ExecuteNonQuery();
            cnBank.Close();
            return null;
        }
    }
}
